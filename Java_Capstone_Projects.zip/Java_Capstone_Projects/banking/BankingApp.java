package banking;

import java.util.Scanner;

public class BankingApp {
    private Account[] accounts;
    private int count;
    private Scanner sc;
    private int nextAccountNumber = 1001;

    public BankingApp(int size) {
        accounts = new Account[size];
        count = 0;
        sc = new Scanner(System.in);
    }

    public void createAccount() {
        if (count >= accounts.length) {
            System.out.println("Account storage full.");
            return;
        }
        System.out.print("Enter account holder name: ");
        String name = sc.nextLine();
        System.out.print("Enter initial deposit amount: ");
        double deposit = Double.parseDouble(sc.nextLine());
        System.out.print("Enter email address: ");
        String email = sc.nextLine();
        System.out.print("Enter phone number: ");
        String phone = sc.nextLine();
        Account a = new Account(nextAccountNumber++, name, deposit, email, phone);
        accounts[count++] = a;
        System.out.println("Account created successfully with Account Number: " + a.getAccountNumber());
    }

    private Account findAccount(int accNo) {
        for (int i = 0; i < count; i++) {
            if (accounts[i].getAccountNumber() == accNo) return accounts[i];
        }
        return null;
    }

    public void performDeposit() {
        System.out.print("Enter account number: ");
        int acc = Integer.parseInt(sc.nextLine());
        Account a = findAccount(acc);
        if (a == null) { System.out.println("Account not found."); return; }
        System.out.print("Enter amount to deposit: ");
        double amt = Double.parseDouble(sc.nextLine());
        if (a.deposit(amt)) System.out.println("Deposit successful. New balance: " + a.getBalance());
    }

    public void performWithdrawal() {
        System.out.print("Enter account number: ");
        int acc = Integer.parseInt(sc.nextLine());
        Account a = findAccount(acc);
        if (a == null) { System.out.println("Account not found."); return; }
        System.out.print("Enter amount to withdraw: ");
        double amt = Double.parseDouble(sc.nextLine());
        if (a.withdraw(amt)) System.out.println("Withdrawal successful. New balance: " + a.getBalance());
    }

    public void showAccountDetails() {
        System.out.print("Enter account number: ");
        int acc = Integer.parseInt(sc.nextLine());
        Account a = findAccount(acc);
        if (a == null) { System.out.println("Account not found."); return; }
        a.displayAccountDetails();
    }

    public void updateContact() {
        System.out.print("Enter account number: ");
        int acc = Integer.parseInt(sc.nextLine());
        Account a = findAccount(acc);
        if (a == null) { System.out.println("Account not found."); return; }
        System.out.print("Enter new email: ");
        String email = sc.nextLine();
        System.out.print("Enter new phone: ");
        String phone = sc.nextLine();
        a.updateContactDetails(email, phone);
        System.out.println("Contact details updated.");
    }

    public void mainMenu() {
        while (true) {
            System.out.println("""\
Welcome to the Banking Application!
1. Create a new account
2. Deposit money
3. Withdraw money
4. View account details
5. Update contact details
6. Exit""");
            System.out.print("Enter your choice: ");
            String choice = sc.nextLine();
            switch (choice) {
                case "1": createAccount(); break;
                case "2": performDeposit(); break;
                case "3": performWithdrawal(); break;
                case "4": showAccountDetails(); break;
                case "5": updateContact(); break;
                case "6": System.out.println("Goodbye!"); return;
                default: System.out.println("Invalid choice.");
            }
        }
    }

    public static void main(String[] args) {
        BankingApp app = new BankingApp(50);
        app.mainMenu();
    }
}
