package student;

import java.util.Scanner;

public class ResultManager {
    private Student[] students;
    private int count;
    private Scanner sc;

    public ResultManager(int size) {
        students = new Student[size];
        count = 0;
        sc = new Scanner(System.in);
    }

    public void addStudent() {
        try {
            System.out.print("Enter Roll Number: "); int roll = Integer.parseInt(sc.nextLine());
            System.out.print("Enter Student Name: "); String name = sc.nextLine();
            int[] marks = new int[3];
            for (int i = 0; i < 3; i++) {
                System.out.print("Enter marks for subject " + (i+1) + ": ");
                marks[i] = Integer.parseInt(sc.nextLine());
            }
            Student s = new Student(roll, name, marks);
            s.validateMarks();
            students[count++] = s;
            System.out.println("Student added successfully.");
        } catch (InvalidMarksException ime) {
            System.out.println("Error: " + ime.getMessage() + ". Returning to main menu...");
        } catch (NumberFormatException nfe) {
            System.out.println("Input mismatch. Returning to main menu...");
        } catch (ArrayIndexOutOfBoundsException aio) {
            System.out.println("Storage full.");
        }
    }

    public void showStudentDetails() {
        System.out.print("Enter Roll Number to search: ");
        try {
            int roll = Integer.parseInt(sc.nextLine());
            for (int i = 0; i < count; i++) {
                // assume unique roll numbers
                java.lang.reflect.Field f;
                // quick compare (access via getter not necessary)
                // We'll just use the Student object's display if found by matching roll using reflection
                java.lang.Class<?> c = students[i].getClass();
                java.lang.reflect.Field rf = c.getDeclaredField("rollNumber");
                rf.setAccessible(true);
                int r = rf.getInt(students[i]);
                if (r == roll) {
                    students[i].displayResult();
                    return;
                }
            }
            System.out.println("Student not found.");
        } catch (Exception e) {
            System.out.println("Error searching student.");
        }
    }

    public void mainMenu() {
        while (true) {
            System.out.println("""\
===== Student Result Management System =====
1. Add Student
2. Show Student Details
3. Exit""");
            System.out.print("Enter your choice: ");
            String choice = sc.nextLine();
            switch (choice) {
                case "1": addStudent(); break;
                case "2": showStudentDetails(); break;
                case "3": System.out.println("Goodbye!"); return;
                default: System.out.println("Invalid choice.");
            }
        }
    }

    public static void main(String[] args) {
        ResultManager rm = new ResultManager(50);
        rm.mainMenu();
    }
}
