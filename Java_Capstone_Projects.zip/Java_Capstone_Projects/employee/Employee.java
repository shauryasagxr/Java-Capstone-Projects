package employee;

public class Employee {
    protected int employeeId;
    protected String name;
    protected double salary;

    public Employee(int employeeId, String name, double salary) {
        this.employeeId = employeeId;
        this.name = name;
        this.salary = salary;
    }

    public double calculateBonus() {
        return salary * 0.10; // base 10%
    }

    public void displayDetails() {
        System.out.printf("Employee ID: %d, Name: %s, Salary: %.2f, Bonus: %.2f\n", employeeId, name, salary, calculateBonus());
    }
}
