package employee;

import java.util.Scanner;

public class ManagementSystem {
    private Employee[] employees;
    private int count;
    private Scanner sc;

    public ManagementSystem(int size) {
        employees = new Employee[size];
        count = 0;
        sc = new Scanner(System.in);
    }

    public void addManager() {
        System.out.print("Enter Manager ID: "); int id = Integer.parseInt(sc.nextLine());
        System.out.print("Enter name: "); String name = sc.nextLine();
        System.out.print("Enter salary: "); double sal = Double.parseDouble(sc.nextLine());
        System.out.print("Enter department: "); String dept = sc.nextLine();
        employees[count++] = new Manager(id, name, sal, dept);
        System.out.println("Manager added successfully.");
    }

    public void addDeveloper() {
        System.out.print("Enter Developer ID: "); int id = Integer.parseInt(sc.nextLine());
        System.out.print("Enter name: "); String name = sc.nextLine();
        System.out.print("Enter salary: "); double sal = Double.parseDouble(sc.nextLine());
        System.out.print("Enter programming language: "); String lang = sc.nextLine();
        employees[count++] = new Developer(id, name, sal, lang);
        System.out.println("Developer added successfully.");
    }

    public void displayEmployeeDetails() {
        System.out.print("Enter Employee ID to search: "); int id = Integer.parseInt(sc.nextLine());
        for (int i = 0; i < count; i++) {
            if (employees[i].employeeId == id) {
                employees[i].displayDetails();
                return;
            }
        }
        System.out.println("Employee not found.");
    }

    public void displayAllEmployees() {
        for (int i = 0; i < count; i++) {
            employees[i].displayDetails();
        }
    }

    public void mainMenu() {
        while (true) {
            System.out.println("""\
Welcome to the Employee Management System!
1. Add Manager
2. Add Developer
3. Display Employee Details
4. Display All Employees
5. Exit""");
            System.out.print("Enter your choice: ");
            String choice = sc.nextLine();
            switch (choice) {
                case "1": addManager(); break;
                case "2": addDeveloper(); break;
                case "3": displayEmployeeDetails(); break;
                case "4": displayAllEmployees(); break;
                case "5": System.out.println("Goodbye!"); return;
                default: System.out.println("Invalid choice.");
            }
        }
    }

    public static void main(String[] args) {
        ManagementSystem sys = new ManagementSystem(50);
        sys.mainMenu();
    }
}
