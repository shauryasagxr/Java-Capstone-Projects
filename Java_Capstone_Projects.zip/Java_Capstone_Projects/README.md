# Java Capstone Projects (5)

This repository contains 5 separate Java console applications prepared for the ENCS201/ENCA203/ENBC205 capstone assignment.

Projects included:
1. Banking Application (package: banking)
2. Employee Management System (package: employee)
3. Student Result Management System (package: student)
4. Contact List Application (package: contact)
5. Library Management System (package: library)

## How the repository is organized
Each project is inside its own package folder and contains a `main` class you can run.

Example structure:
```
Java_Capstone_Projects/
  banking/
    Account.java
    BankingApp.java
  employee/
    Employee.java
    Manager.java
    Developer.java
    ManagementSystem.java
  student/
    Student.java
    InvalidMarksException.java
    ResultManager.java
  contact/
    Contact.java
    ContactManager.java
    ContactListApp.java
  library/
    Book.java
    Library.java
    LibraryApp.java
  README.md
  .gitignore
```

## How to compile and run (VS Code / command line)

1. Open a terminal in the root directory (where the `banking`, `employee`, ... folders are).
2. To compile a package (example: banking):
   ```
   javac banking/*.java
   ```
3. To run (example: BankingApp):
   ```
   java banking.BankingApp
   ```
4. For other projects, replace `banking` with `employee`, `student`, `contact`, or `library` and run their respective main classes:
   - `java employee.ManagementSystem`
   - `java student.ResultManager`
   - `java contact.ContactListApp`
   - `java library.LibraryApp`

## GitHub ready
- Create a new GitHub repository.
- Initialize locally:
  ```
  git init
  git add .
  git commit -m "Add Java capstone projects"
  git branch -M main
  git remote add origin <YOUR_GIT_REMOTE_URL>
  git push -u origin main
  ```

## Notes
- These are simple console applications intended for learning and to demonstrate Java features requested in the assignment.
- You can extend features ( persistence using serialization/ databases, GUIs, unit tests ) as required.
