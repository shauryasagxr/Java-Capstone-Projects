package library;

import java.util.Scanner;

public class LibraryApp {
    private Library library;
    private Scanner sc;

    public LibraryApp(int capacity) {
        library = new Library(capacity);
        sc = new Scanner(System.in);
    }

    public void addBook() {
        System.out.print("Enter book title: ");
        String title = sc.nextLine();
        System.out.print("Enter author: ");
        String author = sc.nextLine();
        library.addBook(new Book(title, author));
        System.out.println("Book added.");
    }

    public void searchByTitle() {
        System.out.print("Enter book title: ");
        String title = sc.nextLine();
        int idx = library.searchBook(title);
        if (idx == -1) System.out.println("Book not found.");
        else System.out.println("Found: " + title);
    }

    public void searchByAuthor() {
        System.out.print("Enter author: ");
        String author = sc.nextLine();
        int idx = library.searchBookByAuthor(author);
        if (idx == -1) System.out.println("No books by that author found.");
        else System.out.println("Found a book by " + author);
    }

    public void borrowBook() {
        System.out.print("Enter book title to borrow: ");
        String title = sc.nextLine();
        library.borrowBook(title);
    }

    public void returnBook() {
        System.out.print("Enter book title to return: ");
        String title = sc.nextLine();
        library.returnBook(title);
    }

    public void displayAll() {
        library.displayAllBooks();
    }

    public void mainMenu() {
        while (true) {
            System.out.println("""\
Welcome to the Library Management System!
1. Add a new book
2. Search for a book by title
3. Search for books by author
4. Borrow a book
5. Return a book
6. Display all books
7. Exit""");
            System.out.print("Enter your choice: ");
            String choice = sc.nextLine();
            switch (choice) {
                case "1": addBook(); break;
                case "2": searchByTitle(); break;
                case "3": searchByAuthor(); break;
                case "4": borrowBook(); break;
                case "5": returnBook(); break;
                case "6": displayAll(); break;
                case "7": System.out.println("Goodbye!"); return;
                default: System.out.println("Invalid choice.");
            }
        }
    }

    public static void main(String[] args) {
        LibraryApp app = new LibraryApp(100);
        app.mainMenu();
    }
}
