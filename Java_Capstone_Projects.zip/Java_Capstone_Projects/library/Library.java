package library;

public class Library {
    private Book[] books;
    private int count;

    public Library(int capacity) {
        books = new Book[capacity];
        count = 0;
    }

    public void addBook(Book b) {
        if (count < books.length) books[count++] = b;
        else System.out.println("Library full.");
    }

    // search by title
    public int searchBook(String title) {
        for (int i = 0; i < count; i++) {
            if (books[i].getTitle().equalsIgnoreCase(title)) return i;
        }
        return -1;
    }

    // search by author (returns first match index)
    public int searchBookByAuthor(String author) {
        for (int i = 0; i < count; i++) {
            if (books[i].getAuthor().equalsIgnoreCase(author)) return i;
        }
        return -1;
    }

    public void borrowBook(String title) {
        int idx = searchBook(title);
        if (idx == -1) { System.out.println("Book not found."); return; }
        if (!books[idx].isAvailable()) { System.out.println("Book already borrowed."); return; }
        books[idx].borrow();
        System.out.println("Book borrowed successfully.");
    }

    public void returnBook(String title) {
        int idx = searchBook(title);
        if (idx == -1) { System.out.println("Book not found."); return; }
        books[idx].returned();
        System.out.println("Book returned successfully.");
    }

    public void displayAllBooks() {
        for (int i = 0; i < count; i++) {
            System.out.println(books[i].toString());
        }
    }
}
