package contact;

import java.util.Scanner;

public class ContactListApp {
    private ContactManager manager;
    private Scanner sc;

    public ContactListApp() {
        manager = new ContactManager();
        sc = new Scanner(System.in);
    }

    public void addContact() {
        System.out.print("Enter contact name: ");
        String name = sc.nextLine();
        System.out.print("Enter phone number: ");
        String phone = sc.nextLine();
        System.out.print("Enter email: ");
        String email = sc.nextLine();
        manager.addContact(new Contact(name, phone, email));
        System.out.println("Contact added successfully.");
    }

    public void searchContact() {
        System.out.print("Enter name to search: ");
        String name = sc.nextLine();
        Contact c = manager.searchContact(name);
        if (c == null) System.out.println("Contact not found.");
        else System.out.println("Found: " + c.getName() + ", " + c.getPhoneNumber() + ", " + c.getEmail());
    }

    public void displayAll() {
        for (Contact c : manager.getAllContacts()) {
            System.out.println(c.getName() + ", " + c.getPhoneNumber() + ", " + c.getEmail());
        }
    }

    public void saveToFile() {
        System.out.print("Enter filename to save (e.g. contacts.txt): ");
        String fn = sc.nextLine();
        try {
            manager.saveContactsToFile(fn);
            System.out.println("Saved to " + fn);
        } catch (Exception e) {
            System.out.println("Error saving: " + e.getMessage());
        }
    }

    public void loadFromFile() {
        System.out.print("Enter filename to load (e.g. contacts.txt): ");
        String fn = sc.nextLine();
        try {
            manager.loadContactsFromFile(fn);
            System.out.println("Loaded from " + fn);
        } catch (Exception e) {
            System.out.println("Error loading: " + e.getMessage());
        }
    }

    public void mainMenu() {
        while (true) {
            System.out.println("""\
Welcome to the Contact List Application!
1. Add Contact
2. Search Contact
3. Display All Contacts
4. Save to File
5. Load from File
6. Exit""");
            System.out.print("Enter your choice: ");
            String choice = sc.nextLine();
            switch (choice) {
                case "1": addContact(); break;
                case "2": searchContact(); break;
                case "3": displayAll(); break;
                case "4": saveToFile(); break;
                case "5": loadFromFile(); break;
                case "6": System.out.println("Goodbye!"); return;
                default: System.out.println("Invalid choice.");
            }
        }
    }

    public static void main(String[] args) {
        new ContactListApp().mainMenu();
    }
}
