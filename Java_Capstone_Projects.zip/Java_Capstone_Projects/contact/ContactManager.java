package contact;

import java.io.*;
import java.util.*;

public class ContactManager {
    private Map<String, Contact> contacts;

    public ContactManager() {
        contacts = new HashMap<>();
    }

    public void addContact(Contact c) {
        contacts.put(c.getName(), c);
    }

    public Contact searchContact(String name) {
        return contacts.get(name);
    }

    public void removeContact(String name) {
        contacts.remove(name);
    }

    public List<Contact> getAllContacts() {
        return new ArrayList<>(contacts.values());
    }

    public void saveContactsToFile(String filename) throws IOException {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(filename))) {
            for (Contact c : contacts.values()) {
                bw.write(c.toString());
                bw.newLine();
            }
        }
    }

    public void loadContactsFromFile(String filename) throws IOException {
        contacts.clear();
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(";");
                if (parts.length >= 3) {
                    Contact c = new Contact(parts[0], parts[1], parts[2]);
                    contacts.put(c.getName(), c);
                }
            }
        }
    }
}
